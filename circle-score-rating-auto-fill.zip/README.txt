A Pen created at CodePen.io. You can find this one at http://codepen.io/paolomazzacani/pen/cAnpy.

 Auto fill score circle that takes the data score assigned to one of them and make the circle fill in based on which is the rate. This functionality is made by css3 and Jquery. 